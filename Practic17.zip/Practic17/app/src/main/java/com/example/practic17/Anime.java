package com.example.practic17;

public class Anime {
    private int ID_Anime;
    private final String Anime_Name;
    private final String Anime_Descr;

    public Anime(String animeName, String animeDescr) {
        this.Anime_Name = animeName;
        this.Anime_Descr = animeDescr;
    }
    public Anime(int animeId, String animeName, String animeDescr) {
        this.ID_Anime = animeId;
        this.Anime_Name = animeName;
        this.Anime_Descr = animeDescr;
    }

    public int getID_Anime() {
        return ID_Anime;
    }

    public String getAnime_Name() {
        return Anime_Name;
    }

    public String getAnime_Descr() {
        return Anime_Descr;
    }
}
