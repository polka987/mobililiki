package com.example.practic17;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DetailActivity extends AppCompatActivity {
    EditText nameEdit, descrEdit;
    Button addEne, delete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        nameEdit = findViewById(R.id.nameEd);
        descrEdit = findViewById(R.id.descripEd);
        addEne = findViewById(R.id.add);
        delete = findViewById(R.id.delete);
        Intent intent = getIntent();
        if(intent != null) {
            int energoId = intent.getIntExtra("animeId", 0);
            DataBaseHelper dataBaseHelper = new DataBaseHelper(this);
            dataBaseHelper.getAnimeById(energoId);
            nameEdit.setText(dataBaseHelper.getAnimeById(energoId).getAnime_Name());
            descrEdit.setText(dataBaseHelper.getAnimeById(energoId).getAnime_Descr());
            addEne.setText("Изменить");
            delete.setVisibility(View.VISIBLE);
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dataBaseHelper.delete(energoId);
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
            addEne.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dataBaseHelper.updateAnime(energoId, nameEdit.getText().toString(), descrEdit.getText().toString());
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
        }
    }
}