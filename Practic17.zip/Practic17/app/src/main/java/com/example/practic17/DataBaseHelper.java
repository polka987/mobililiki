package com.example.practic17;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "anime.db";
    private static final int SCHEMA = 1;
    private static final String TABLE_NAME = "anime";


    private static final String COLUMN_ID = "id_anime";
    private static final String COLUMN_NAME = "anime_name";
    private static final String COLUMN_DESCRIPTION = "anime_descr";

    public DataBaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, SCHEMA);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + COLUMN_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_NAME
                + " TEXT, " + COLUMN_DESCRIPTION + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addAnime(Anime anime){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, anime.getAnime_Name());
        contentValues.put(COLUMN_DESCRIPTION, anime.getAnime_Descr());

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }
    public void updateAnime(int animeId, String newName, String newDescription) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, newName);
        values.put(COLUMN_DESCRIPTION, newDescription);

        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(animeId) };

        sqLiteDatabase.update(TABLE_NAME, values, selection, selectionArgs);
    }

    public void delete(int id){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };
        sqLiteDatabase.delete(TABLE_NAME, selection, selectionArgs);
    }

    public Anime getAnimeById(int id){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        String[] columns = {COLUMN_NAME, COLUMN_DESCRIPTION};
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = {Integer.toString(id)};

        Cursor cursor = sqLiteDatabase.query(
                TABLE_NAME,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        Anime anime = null;
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
            @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION));
            anime = new Anime(name, description);
            cursor.close();
        }
        return anime;
    }

    public ArrayList<Anime> getAnimeList(){
        ArrayList<Anime> animeList = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        if(result.moveToFirst()){
            while(result.moveToNext()){
                @SuppressLint("Range") int animeId = result.getInt(result.getColumnIndex(COLUMN_ID));
                String animeName = result.getString(1);
                String animeDescr = result.getString(2);
                Anime anime = new Anime(animeId, animeName, animeDescr);
                animeList.add(anime);
            }
        }
        result.close();
        return animeList;
    }
}
