package com.example.practic17;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        EditText nameEd = findViewById(R.id.nameEd);
        EditText descrEd = findViewById(R.id.descripEd);
        Button Add_Anime = findViewById(R.id.add);

        DataBaseHelper dataBaseHelper = new DataBaseHelper(this);

        Add_Anime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Anime anime = new Anime(nameEd.getText().toString(),
                        descrEd.getText().toString());
                try {
                    dataBaseHelper.addAnime(anime);
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }catch (Exception e){
                    Toast.makeText(AddActivity.this, "ошибка при добавлении аниме", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}